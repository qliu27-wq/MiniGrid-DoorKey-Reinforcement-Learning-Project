import os
import gymnasium as gym
from minigrid.wrappers import FullyObsWrapper
from stable_baselines3 import PPO
from stable_baselines3.common.torch_layers import NatureCNN
from stable_baselines3.common.vec_env import DummyVecEnv
import torch as th

BASE_DIR = "C:\\Users\\21753\\Desktop\\RL2"
MODEL_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(MODEL_DIR, exist_ok=True)

#  自定义 CNN 架构（适配 MiniGrid 输入）
class MiniGridCNN(NatureCNN):
    def __init__(self, observation_space, features_dim=128):
        super(NatureCNN, self).__init__(observation_space, features_dim)

        # **修正输入通道问题，确保输入为 (3, 5, 5)**
        self.cnn = th.nn.Sequential(
            th.nn.Conv2d(3, 16, kernel_size=2, stride=1),  # 确保输入通道是 3
            th.nn.ReLU(),
            th.nn.Conv2d(16, 32, kernel_size=2, stride=1),
            th.nn.ReLU(),
            th.nn.Flatten(),
        )

        # **计算全连接层输入维度**
        with th.no_grad():
            sample = th.as_tensor(observation_space.sample()[None]).float()
            sample = sample[:, :3, :, :]  #  只取前 3 个通道
            n_flatten = self.cnn(sample).shape[1]

        self.linear = th.nn.Sequential(
            th.nn.Linear(n_flatten, features_dim),
            th.nn.ReLU()
        )

    def forward(self, observations):
        observations = observations[:, :3, :, :]  # ✅ 确保输入只有 3 个通道
        return self.linear(self.cnn(observations))

# 创建环境（提取图像观测并交换通道维度）
class ExtractImageObservation(gym.ObservationWrapper):
    def __init__(self, env):
        super().__init__(env)
        assert isinstance(env.observation_space, gym.spaces.Dict)

        #  **修正 observation_space 形状**
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=(3, 5, 5), dtype=env.observation_space["image"].dtype
        )

    def observation(self, obs):
        image = obs["image"][:, :, :3]  # 只保留前 3 个通道
        image = image.transpose(2, 0, 1)  #  交换维度 (H, W, C) -> (C, H, W)
    ##    print(f" 处理后 image 维度: {image.shape}")  #  调试信息
        return image

def create_env():
    env = gym.make("MiniGrid-DoorKey-5x5-v0", render_mode="rgb_array")
    env = FullyObsWrapper(env)
    env = ExtractImageObservation(env)  #  确保通道顺序是 (3, 5, 5)
    return env

def train_agent(timesteps=500000, model_name="ppo_minigrid"):  #训练50w次
    model_path = os.path.join(MODEL_DIR, model_name)
    env = DummyVecEnv([lambda: create_env()])
    
    # 使用自定义 CNN 策略
    policy_kwargs = dict(
        features_extractor_class=MiniGridCNN,
        features_extractor_kwargs=dict(features_dim=64)
    )
    model = PPO(
        "CnnPolicy", 
        env, 
        policy_kwargs=policy_kwargs,
        verbose=1
    )
    model.learn(total_timesteps=timesteps,progress_bar=True)
    model.save(model_path)
    print(f" 训练完成，模型已保存到: {model_path}.zip")

if __name__ == "__main__":
    train_agent()
