import os
import gymnasium as gym
import time
import numpy as np
from minigrid.wrappers import FullyObsWrapper
from stable_baselines3 import PPO



# 设定模型路径
BASE_DIR = "C:\\Users\\21753\\Desktop\\RL2"
MODEL_PATH = os.path.join(BASE_DIR, "models", "ppo_minigrid.zip")

#  确保环境只返回 `image`
class ExtractImageObservation(gym.ObservationWrapper):
    def __init__(self, env):
        super().__init__(env)
        assert isinstance(env.observation_space, gym.spaces.Dict)
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=(3, 5, 5), dtype=np.uint8
        )

    def observation(self, obs):
        return obs["image"][:, :, :3].transpose(2, 0, 1)

def create_env():
    env = gym.make("MiniGrid-DoorKey-5x5-v0", render_mode="human", max_steps=100)
    env = FullyObsWrapper(env)  
    env = ExtractImageObservation(env)
    return env

# 测试智能体（增加 `pick up` 拿钥匙的逻辑）
def test_agent():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f" 模型文件 {MODEL_PATH} 不存在，请先运行 `train.py` 训练！")

    env = create_env()
    model = PPO.load(MODEL_PATH)

    obs, _ = env.reset()
    carrying_key = False  # 记录智能体是否拿到了钥匙

    for _ in range(1000):  # 运行 1000 步
        env.render()
        obs = np.array(obs)
        print(obs)

        # 提取观测信息（使用 `env.unwrapped` 访问原始 MiniGrid 环境）
        agent_x, agent_y = env.unwrapped.agent_pos
        grid = env.unwrapped.grid.encode()

        # 检查智能体是否在钥匙位置
        if not carrying_key:
            key_x, key_y = None, None
            for x in range(grid.shape[0]):
                for y in range(grid.shape[1]):
                    if grid[x, y, 0] == 8:  # 8 代表钥匙
                        key_x, key_y = x, y
                        break
            if key_x is not None and agent_x == key_x and agent_y == key_y:
                action = 6  # 6 = `pick up` 拿起钥匙
                carrying_key = True  # 标记为已拿钥匙
                print("智能体捡起了钥匙！")
            else:
                action, _ = model.predict(obs)  # 继续使用训练的策略

        #  如果已经拿到钥匙，尝试开门
        elif carrying_key:
            door_x, door_y = None, None
            for x in range(grid.shape[0]):
                for y in range(grid.shape[1]):
                    if grid[x, y, 0] == 4:  # 4 代表门
                        door_x, door_y = x, y
                        break
            if door_x is not None and agent_x == door_x and agent_y == door_y:
                action = 5  # 5 = `toggle`（开门）
                print("智能体打开了门！")
            else:
                action, _ = model.predict(obs)  # 继续使用训练的策略

        # 执行智能体的动作
        obs, reward, done, _, _ = env.step(action)
        print(f"智能体动作: {action}, 奖励: {reward}, 终止: {done}")
        time.sleep(0.3)

        if done:
            print(" 任务完成，环境重置...")
            obs, _ = env.reset()
            carrying_key = False  # 重新初始化钥匙状态

if __name__ == "__main__":
    test_agent()
